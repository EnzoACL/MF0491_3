# Prueba práctica

Prueba práctica que consiste en la creacion de una pagina que registre las veces que se pulsa un botón.
