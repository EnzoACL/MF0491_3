//Se establece un handler que ejecute la funcion "sumarUnoHandler"
//cada vez que se presiona el boton de clase ".pulsador"
document.querySelector(".pulsador").addEventListener("click", sumarUnoHandler);

//La variable counter se establece fuera de la funcion para que 
//pertenezca al ambito global y asi su valor se mantenga.
let counter = 0

//Funcion encargada de incrementar el numero en el HTML con id=counter.
function sumarUnoHandler() {    
    counter++;
    document.querySelector("#counter").innerHTML = counter; 
}
